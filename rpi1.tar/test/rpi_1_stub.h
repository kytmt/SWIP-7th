#ifndef _STUB_H_
#define _STUB_H_

#include "rpi_1_can.h"

extern int moveMotor(const int inputValue);
extern int displayText(const int lineNum, const char *text);
extern int terminateRPC(const char* text);

#endif