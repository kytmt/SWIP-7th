#ifndef _CAN_H_
#define _CAN_H_

#include "rpi_1_stub.h"

#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>

#define PACKET_SIZE 36

extern int socketCANDescriptor;
extern struct sockaddr_can addr;
extern struct ifreq ifr;
extern struct can_frame frame;

typedef struct Data
{
        int i_data;
        char str_data[16];

}DATA;

struct sendData{
        char func[16]; // 16
        DATA data;  // 20
};

// total 36 bytes

struct recvData{
        int ret;
};

extern int initializeCAN();
extern int can1_send(const char* cmd, DATA args);
extern int can1_recv();
extern int terminateCAN();

#endif

