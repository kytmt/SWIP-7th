#ifndef _ULTRASONIC_H_
#define _ULTRASONIC_H_

#include <sys/time.h>
#include <stdio.h>

#define Trig    23
#define Echo    24

extern int isInTwenty;
extern float measureDistance(void);
extern void* R1_ultrasonic();

#endif