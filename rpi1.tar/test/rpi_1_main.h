#ifndef _MAIN_H_
#define _MAIN_H_

#include <unistd.h>
#include <sys/time.h>
#include <stdio.h>
#include <pthread.h>

#endif