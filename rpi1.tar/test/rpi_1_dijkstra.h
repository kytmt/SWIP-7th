#ifndef _DIJKSTRA_H_
#define _DIJKSTRA_H_

#include <stdlib.h>
#include <limits.h>
#include <string.h>

extern int V; // 그래프의 정점 수
extern int len;
extern int graph[8][8];

extern int readTxtFile(void);
extern int minDistance(int dist[], int sptSet[]);
extern void printPath(int parent[], int j, char buffer[], int *len);
extern void findShortestPath(int src, int dest, char buffer[], int *len);

#endif