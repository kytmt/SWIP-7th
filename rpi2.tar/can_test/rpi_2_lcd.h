extern int realDisplayText(const int lineNum, const char *text);
extern int initializeLCD();