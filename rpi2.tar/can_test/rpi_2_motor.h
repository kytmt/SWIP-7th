extern int inputValue;
extern int realMoveMotor(int inputValue);

#define PIN 18
#define PWM_RANGE 200