#include "rpi_2_stub.h"
#include "rpi_2_motor.h"
#include "rpi_2_can.h"
#include "rpi_2_lcd.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>

extern int socketCANDescriptor;
extern char str_buf[128];
extern struct sockaddr_can addr;
extern struct ifreq ifr;
extern struct can_frame frame;


int moveMotor(const int inputValue)
{
    int ret;

    //모터 호출
    if( realMoveMotor(inputValue) < 0) {
        perror("realMoverMotor error\n");
        return -1;
    }

    can2_send(inputValue);
    return 0;
}

int displayText(const int lineNum, const char *text)
{
    
    //lcd 호출

    if(realDisplayText(lineNum, text) < 0) {
        perror("realDisplayText error\n");
        return -1;
    }

    if(text[0] != ' ')
        can2_send(strlen(text));
    return 0;
}

int terminateRPC(char* text)
{
        can2_send(0);       

        if (close(socketCANDescriptor) < 0) 
        {
                perror("Close");
                return -1;
        }
}

int runRPCserver()
{
    int cnt = 5; 
    int offset = 0;
    int nbytesReceived;

    
    int inputValue = 0;
    char func[16];
    char str_data[16];

    while(1)
    {
        for(int i = 0 ; i < cnt; i++)
        {

            nbytesReceived = read(socketCANDescriptor, &frame, sizeof(struct can_frame));
                        if (nbytesReceived < 0) {
                                perror("Read failed");
                                return -1;
                        }    
                        memcpy(str_buf + offset, (unsigned char *)(frame.data), frame.can_dlc);
                        offset += frame.can_dlc;

                }
                offset = 0;
                
                //unamrshall 
                memcpy(func, str_buf, 16);
                memcpy(&inputValue, str_buf + 16, 4);
                memcpy(str_data,str_buf+20,16);


                if(!strcmp(func, "moveMotor")) {
                        moveMotor(inputValue);
                } else if(!strcmp(func, "displayText")) {
                        if(inputValue == 1)
                                displayText(2,"                " );
                        displayText(inputValue, "                ");
                        displayText(inputValue, str_data);
                        
                } 

                if(!strcmp(str_data, "quit")) {
                        terminateRPC(str_data);
                        printf("RPC request 'QUIT' commnad received\n");
                        break;
                }

                bzero(str_buf, sizeof(str_buf));;
    }
}
