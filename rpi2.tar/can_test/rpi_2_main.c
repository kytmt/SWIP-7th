#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "wiringPi.h"
#include "wiringPiI2C.h"

#include <net/if.h>

#include <sys/ioctl.h>
#include <sys/socket.h>

#include <linux/can.h>
#include <linux/can/raw.h>

#include "rpi_2_motor.h"
#include "rpi_2_stub.h"
#include "rpi_2_lcd.h"
#include "rpi_2_can.h"

char str_buf[128];
int socketCANDescriptor; 
int deviceHandle;
struct sockaddr_can addr;
struct ifreq ifr;
struct can_frame frame;

int main(void) 
{
        int ret = 0;

        printf("\nRPi #2 is ready to accept RPC requests\n");
        
        ret = wiringPiSetupGpio();
        ret = initializeCAN();
        //ret = intializeserveMotor();
        ret = initializeLCD();

        ret = runRPCserver();

        printf("Terminating RPI #2\n");

        return 0;
}