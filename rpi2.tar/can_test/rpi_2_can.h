
#include "rpi_2_stub.h"


extern int can2_send(int ret);
extern int initializeCAN();

